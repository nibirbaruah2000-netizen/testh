"""AntiNuke window and permission rules. No Discord needed."""
from collections import deque
from types import SimpleNamespace as NS

from utils.antinuke import has_dangerous_permission, record_and_check


def test_triggers_at_threshold():
    window = deque()
    assert not record_and_check(window, 0.0, 10, 3)
    assert not record_and_check(window, 1.0, 10, 3)
    assert record_and_check(window, 2.0, 10, 3)


def test_old_actions_expire_out_of_window():
    window = deque()
    record_and_check(window, 0.0, 10, 3)
    record_and_check(window, 1.0, 10, 3)
    # The first two are now older than 10 seconds, so this is only one action in the window.
    assert not record_and_check(window, 20.0, 10, 3)


def test_window_clears_after_trigger():
    window = deque()
    for t in (0.0, 1.0, 2.0):
        record_and_check(window, t, 10, 3)
    assert not record_and_check(window, 3.0, 10, 3)


def _role(**perms):
    base = {"administrator": False, "manage_guild": False, "manage_roles": False,
            "manage_channels": False, "ban_members": False, "kick_members": False,
            "manage_webhooks": False, "send_messages": True}
    base.update(perms)
    return NS(permissions=NS(**base))


def test_dangerous_permission_detection():
    assert has_dangerous_permission(_role(ban_members=True))
    assert has_dangerous_permission(_role(administrator=True))
    assert not has_dangerous_permission(_role(send_messages=True))
