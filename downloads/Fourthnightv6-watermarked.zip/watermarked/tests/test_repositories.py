"""Guild isolation and per-guild case numbering against a real SQLite file."""
import pytest

from database.repositories import GuildRepository, ModerationRepository
from database.session import Database


@pytest.fixture
async def repos(tmp_path):
    database = Database(f"sqlite+aiosqlite:///{tmp_path / 'test.db'}")
    await database.create_all()
    yield GuildRepository(database.session_factory), ModerationRepository(database.session_factory)
    await database.close()


async def test_guild_configs_are_isolated(repos):
    guilds, _ = repos
    await guilds.update_config(1, mod_role_id=111, log_channel_id=1001)
    await guilds.update_config(2, mod_role_id=222)

    first = await guilds.get_config(1)
    second = await guilds.get_config(2)
    assert first.mod_role_id == 111 and first.log_channel_id == 1001
    assert second.mod_role_id == 222 and second.log_channel_id is None


async def test_unknown_config_fields_are_rejected(repos):
    guilds, _ = repos
    with pytest.raises(ValueError):
        await guilds.update_config(1, guild_id=999)


async def test_case_numbers_are_sequential_per_guild(repos):
    _, moderation = repos
    a1 = await moderation.add_case(1, 50, 60, "kick", "spam")
    a2 = await moderation.add_case(1, 51, 60, "ban", "raid")
    b1 = await moderation.add_case(2, 50, 60, "warn", "rude")
    assert (a1.case_number, a2.case_number, b1.case_number) == (1, 2, 1)


async def test_warnings_count_per_guild(repos):
    _, moderation = repos
    await moderation.add_warning(1, 50, 60, "one")
    await moderation.add_warning(1, 50, 60, "two")
    await moderation.add_warning(2, 50, 60, "elsewhere")
    assert await moderation.count_active_warnings(1, 50) == 2
    assert await moderation.count_active_warnings(2, 50) == 1
    assert await moderation.clear_warnings(1, 50) == 2
    assert await moderation.count_active_warnings(1, 50) == 0
