"""Economy rules against a real SQLite file: funds, cooldowns, and atomic trades."""
from datetime import timedelta

import pytest

from database.economy_repository import EconomyRepository
from database.session import Database


@pytest.fixture
async def econ(tmp_path):
    database = Database(f"sqlite+aiosqlite:///{tmp_path / 'econ.db'}")
    await database.create_all()
    yield EconomyRepository(database.session_factory)
    await database.close()


async def test_transfer_requires_funds(econ):
    await econ.add_coins(1, 50)
    assert not await econ.transfer(1, 2, 100)
    assert (await econ.get_wallet(1)).coins == 50


async def test_transfer_moves_coins(econ):
    await econ.add_coins(1, 100)
    assert await econ.transfer(1, 2, 40)
    assert (await econ.get_wallet(1)).coins == 60
    assert (await econ.get_wallet(2)).coins == 40


async def test_cooldown_blocks_second_claim(econ):
    assert await econ.claim_cooldown(1, "last_work", timedelta(hours=1)) is None
    remaining = await econ.claim_cooldown(1, "last_work", timedelta(hours=1))
    assert remaining is not None
    assert remaining > timedelta(minutes=50)


async def test_failed_trade_leaves_items_with_seller(econ):
    item = await econ.create_item(1, "Sword", 100, "", 9)
    await econ.give_item(10, item.id, 1)
    ok = await econ.execute_trade(seller_id=10, buyer_id=20, item_id=item.id, quantity=1, price=500)
    assert not ok
    assert await econ.get_quantity(10, item.id) == 1
    assert await econ.get_quantity(20, item.id) == 0


async def test_successful_trade_moves_items_and_coins(econ):
    item = await econ.create_item(1, "Shield", 100, "", 9)
    await econ.give_item(10, item.id, 2)
    await econ.add_coins(20, 500)
    ok = await econ.execute_trade(seller_id=10, buyer_id=20, item_id=item.id, quantity=1, price=300)
    assert ok
    assert await econ.get_quantity(10, item.id) == 1
    assert await econ.get_quantity(20, item.id) == 1
    assert (await econ.get_wallet(20)).coins == 200
    assert (await econ.get_wallet(10)).coins == 300
