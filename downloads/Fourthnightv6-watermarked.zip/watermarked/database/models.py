"""SQLAlchemy ORM models. Every guild-scoped table carries guild_id."""
from datetime import datetime, timezone

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow() -> datetime:
    """Return the current time as a timezone-aware UTC datetime."""
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    """Declarative base for all models."""


class GuildConfig(Base):
    """Per-server settings. Rows are never shared between guilds."""

    __tablename__ = "guild_configs"

    guild_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    mod_role_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    log_channel_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    warn_timeout_threshold: Mapped[int] = mapped_column(Integer, default=3)
    warn_kick_threshold: Mapped[int] = mapped_column(Integer, default=5)
    warn_ban_threshold: Mapped[int] = mapped_column(Integer, default=7)
    auto_timeout_minutes: Mapped[int] = mapped_column(Integer, default=60)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class WarningRecord(Base):
    """A single warning issued to a member of a guild."""

    __tablename__ = "warnings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    guild_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    moderator_id: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ModCase(Base):
    """A moderation action. case_number is sequential within each guild."""

    __tablename__ = "mod_cases"
    __table_args__ = (UniqueConstraint("guild_id", "case_number", name="uq_case_per_guild"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_number: Mapped[int] = mapped_column(Integer)
    guild_id: Mapped[int] = mapped_column(BigInteger, index=True)
    target_id: Mapped[int] = mapped_column(BigInteger, index=True)
    moderator_id: Mapped[int] = mapped_column(BigInteger)
    action: Mapped[str] = mapped_column(String(32))
    reason: Mapped[str] = mapped_column(Text)
    duration_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Wallet(Base):
    """Global per-user economy. Shared across every server the bot is in."""

    __tablename__ = "wallets"

    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    coins: Mapped[int] = mapped_column(BigInteger, default=0)
    bank: Mapped[int] = mapped_column(BigInteger, default=0)
    reputation: Mapped[int] = mapped_column(Integer, default=0)
    bio: Mapped[str | None] = mapped_column(String(190), nullable=True)
    last_daily: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_weekly: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_work: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_rob: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_rep_given: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ShopItem(Base):
    """An item sold by one server's shop. Its ID works for buying from any server."""

    __tablename__ = "shop_items"
    __table_args__ = (UniqueConstraint("guild_id", "name", name="uq_item_name_per_guild"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    guild_id: Mapped[int] = mapped_column(BigInteger, index=True)
    name: Mapped[str] = mapped_column(String(64))
    description: Mapped[str] = mapped_column(String(200), default="")
    price: Mapped[int] = mapped_column(BigInteger)
    created_by: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class InventoryEntry(Base):
    """How many of one item a user owns."""

    __tablename__ = "inventory_entries"
    __table_args__ = (UniqueConstraint("user_id", "item_id", name="uq_inventory_user_item"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    item_id: Mapped[int] = mapped_column(Integer, index=True)
    quantity: Mapped[int] = mapped_column(Integer, default=0)


class AntiNukeSettings(Base):
    """Per-server AntiNuke configuration. Disabled until a server turns it on."""

    __tablename__ = "antinuke_settings"

    guild_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    threshold: Mapped[int] = mapped_column(Integer, default=3)
    window_seconds: Mapped[int] = mapped_column(Integer, default=10)
    punishment: Mapped[str] = mapped_column(String(16), default="strip")


class AntiNukeAllowlist(Base):
    """Users exempt from AntiNuke in one server (e.g. trusted admins or bots)."""

    __tablename__ = "antinuke_allowlist"
    __table_args__ = (UniqueConstraint("guild_id", "user_id", name="uq_antinuke_allow"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    guild_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger)
