"""AntiNuke settings and allowlist. Every query is scoped to one guild."""
from typing import Any

from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import async_sessionmaker

from database.models import AntiNukeAllowlist, AntiNukeSettings

SETTINGS_FIELDS = frozenset({"enabled", "threshold", "window_seconds", "punishment"})
PUNISHMENTS = frozenset({"strip", "ban"})


class AntiNukeRepository:
    def __init__(self, session_factory: async_sessionmaker) -> None:
        self._sessions = session_factory

    async def get_settings(self, guild_id: int) -> AntiNukeSettings:
        async with self._sessions() as session:
            settings = await session.get(AntiNukeSettings, guild_id)
            if settings is not None:
                return settings
            settings = AntiNukeSettings(
                guild_id=guild_id, enabled=False, threshold=3, window_seconds=10, punishment="strip"
            )
            session.add(settings)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                settings = await session.get(AntiNukeSettings, guild_id)
            return settings

    async def update_settings(self, guild_id: int, **fields: Any) -> AntiNukeSettings:
        unknown = set(fields) - SETTINGS_FIELDS
        if unknown:
            raise ValueError(f"Unknown AntiNuke fields: {sorted(unknown)}")
        if "punishment" in fields and fields["punishment"] not in PUNISHMENTS:
            raise ValueError("Punishment must be 'strip' or 'ban'")

        await self.get_settings(guild_id)
        async with self._sessions() as session, session.begin():
            settings = await session.get(AntiNukeSettings, guild_id)
            for key, value in fields.items():
                setattr(settings, key, value)
        return settings

    async def allow(self, guild_id: int, user_id: int) -> bool:
        async with self._sessions() as session:
            session.add(AntiNukeAllowlist(guild_id=guild_id, user_id=user_id))
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                return False
        return True

    async def disallow(self, guild_id: int, user_id: int) -> bool:
        stmt = delete(AntiNukeAllowlist).where(
            AntiNukeAllowlist.guild_id == guild_id, AntiNukeAllowlist.user_id == user_id
        )
        async with self._sessions() as session, session.begin():
            result = await session.execute(stmt)
            return (result.rowcount or 0) == 1

    async def allowlist(self, guild_id: int) -> list[int]:
        stmt = select(AntiNukeAllowlist.user_id).where(AntiNukeAllowlist.guild_id == guild_id)
        async with self._sessions() as session:
            return list((await session.execute(stmt)).scalars().all())
