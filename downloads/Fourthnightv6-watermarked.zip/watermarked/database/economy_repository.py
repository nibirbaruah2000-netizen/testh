"""Global economy: wallets, cooldowns, shops, and inventories. Shared across every server."""
from datetime import timedelta, timezone

from sqlalchemy import delete, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from database.models import InventoryEntry, ShopItem, Wallet, utcnow

COOLDOWN_FIELDS = frozenset(
    {"last_daily", "last_weekly", "last_work", "last_rob", "last_rep_given"}
)


class _Rollback(Exception):
    """Raised inside a transaction to undo it without surfacing an error."""


async def _debit(session: AsyncSession, user_id: int, amount: int) -> bool:
    result = await session.execute(
        update(Wallet)
        .where(Wallet.user_id == user_id, Wallet.coins >= amount)
        .values(coins=Wallet.coins - amount)
    )
    return result.rowcount == 1


async def _credit(session: AsyncSession, user_id: int, amount: int) -> None:
    await session.execute(
        update(Wallet).where(Wallet.user_id == user_id).values(coins=Wallet.coins + amount)
    )


async def _take_item(session: AsyncSession, user_id: int, item_id: int, quantity: int) -> bool:
    result = await session.execute(
        update(InventoryEntry)
        .where(
            InventoryEntry.user_id == user_id,
            InventoryEntry.item_id == item_id,
            InventoryEntry.quantity >= quantity,
        )
        .values(quantity=InventoryEntry.quantity - quantity)
    )
    if result.rowcount != 1:
        return False
    await session.execute(
        delete(InventoryEntry).where(
            InventoryEntry.user_id == user_id,
            InventoryEntry.item_id == item_id,
            InventoryEntry.quantity == 0,
        )
    )
    return True


async def _give_item(session: AsyncSession, user_id: int, item_id: int, quantity: int) -> None:
    entry = (
        await session.execute(
            select(InventoryEntry).where(
                InventoryEntry.user_id == user_id, InventoryEntry.item_id == item_id
            )
        )
    ).scalar_one_or_none()
    if entry is None:
        session.add(InventoryEntry(user_id=user_id, item_id=item_id, quantity=quantity))
    else:
        entry.quantity += quantity


class EconomyRepository:
    """All economy reads and writes. Money and item moves are atomic."""

    def __init__(self, session_factory: async_sessionmaker) -> None:
        self._sessions = session_factory

    # ----- wallets -------------------------------------------------------

    async def get_wallet(self, user_id: int) -> Wallet:
        async with self._sessions() as session:
            wallet = await session.get(Wallet, user_id)
            if wallet is not None:
                return wallet
            wallet = Wallet(user_id=user_id, coins=0, bank=0, reputation=0, created_at=utcnow())
            session.add(wallet)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                wallet = await session.get(Wallet, user_id)
            return wallet

    async def claim_cooldown(
        self, user_id: int, field: str, cooldown: timedelta
    ) -> timedelta | None:
        """Start a cooldown. Returns None if it started now, or the time left if still active."""
        if field not in COOLDOWN_FIELDS:
            raise ValueError(f"Unknown cooldown field: {field}")
        await self.get_wallet(user_id)

        column = getattr(Wallet, field)
        now = utcnow()
        async with self._sessions() as session, session.begin():
            result = await session.execute(
                update(Wallet)
                .where(
                    Wallet.user_id == user_id,
                    or_(column.is_(None), column <= now - cooldown),
                )
                .values({field: now})
            )
            if result.rowcount == 1:
                return None
            wallet = await session.get(Wallet, user_id)
            last = getattr(wallet, field)

        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        return (last + cooldown) - now

    async def add_coins(self, user_id: int, amount: int) -> None:
        await self.get_wallet(user_id)
        async with self._sessions() as session, session.begin():
            await _credit(session, user_id, amount)

    async def remove_coins(self, user_id: int, amount: int) -> bool:
        await self.get_wallet(user_id)
        try:
            async with self._sessions() as session, session.begin():
                if not await _debit(session, user_id, amount):
                    raise _Rollback
        except _Rollback:
            return False
        return True

    async def transfer(self, from_id: int, to_id: int, amount: int) -> bool:
        await self.get_wallet(from_id)
        await self.get_wallet(to_id)
        try:
            async with self._sessions() as session, session.begin():
                if not await _debit(session, from_id, amount):
                    raise _Rollback
                await _credit(session, to_id, amount)
        except _Rollback:
            return False
        return True

    async def deposit(self, user_id: int, amount: int) -> bool:
        await self.get_wallet(user_id)
        try:
            async with self._sessions() as session, session.begin():
                result = await session.execute(
                    update(Wallet)
                    .where(Wallet.user_id == user_id, Wallet.coins >= amount)
                    .values(coins=Wallet.coins - amount, bank=Wallet.bank + amount)
                )
                if result.rowcount != 1:
                    raise _Rollback
        except _Rollback:
            return False
        return True

    async def withdraw(self, user_id: int, amount: int) -> bool:
        await self.get_wallet(user_id)
        try:
            async with self._sessions() as session, session.begin():
                result = await session.execute(
                    update(Wallet)
                    .where(Wallet.user_id == user_id, Wallet.bank >= amount)
                    .values(bank=Wallet.bank - amount, coins=Wallet.coins + amount)
                )
                if result.rowcount != 1:
                    raise _Rollback
        except _Rollback:
            return False
        return True

    async def add_reputation(self, user_id: int, amount: int = 1) -> None:
        await self.get_wallet(user_id)
        async with self._sessions() as session, session.begin():
            await session.execute(
                update(Wallet)
                .where(Wallet.user_id == user_id)
                .values(reputation=Wallet.reputation + amount)
            )

    async def set_bio(self, user_id: int, bio: str | None) -> None:
        await self.get_wallet(user_id)
        async with self._sessions() as session, session.begin():
            await session.execute(update(Wallet).where(Wallet.user_id == user_id).values(bio=bio))

    async def top_wallets(self, limit: int = 10) -> list[Wallet]:
        stmt = select(Wallet).order_by((Wallet.coins + Wallet.bank).desc()).limit(limit)
        async with self._sessions() as session:
            return list((await session.execute(stmt)).scalars().all())

    # ----- shops ---------------------------------------------------------

    async def create_item(
        self, guild_id: int, name: str, price: int, description: str, created_by: int
    ) -> ShopItem | None:
        item = ShopItem(
            guild_id=guild_id,
            name=name,
            price=price,
            description=description,
            created_by=created_by,
            created_at=utcnow(),
        )
        async with self._sessions() as session:
            session.add(item)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                return None
        return item

    async def remove_item(self, guild_id: int, item_id: int) -> bool:
        async with self._sessions() as session, session.begin():
            result = await session.execute(
                delete(ShopItem).where(ShopItem.id == item_id, ShopItem.guild_id == guild_id)
            )
            return (result.rowcount or 0) == 1

    async def get_item(self, item_id: int) -> ShopItem | None:
        async with self._sessions() as session:
            return await session.get(ShopItem, item_id)

    async def list_items(self, guild_id: int, limit: int = 25) -> list[ShopItem]:
        stmt = (
            select(ShopItem)
            .where(ShopItem.guild_id == guild_id)
            .order_by(ShopItem.price)
            .limit(limit)
        )
        async with self._sessions() as session:
            return list((await session.execute(stmt)).scalars().all())

    async def purchase(self, buyer_id: int, item_id: int, quantity: int, total: int) -> bool:
        await self.get_wallet(buyer_id)
        try:
            async with self._sessions() as session, session.begin():
                if not await _debit(session, buyer_id, total):
                    raise _Rollback
                await _give_item(session, buyer_id, item_id, quantity)
        except _Rollback:
            return False
        return True

    async def sell(self, seller_id: int, item_id: int, quantity: int, payout: int) -> bool:
        await self.get_wallet(seller_id)
        try:
            async with self._sessions() as session, session.begin():
                if not await _take_item(session, seller_id, item_id, quantity):
                    raise _Rollback
                await _credit(session, seller_id, payout)
        except _Rollback:
            return False
        return True

    async def execute_trade(
        self, seller_id: int, buyer_id: int, item_id: int, quantity: int, price: int
    ) -> bool:
        """Move items from seller to buyer and coins from buyer to seller, all or nothing."""
        await self.get_wallet(seller_id)
        await self.get_wallet(buyer_id)
        try:
            async with self._sessions() as session, session.begin():
                if not await _take_item(session, seller_id, item_id, quantity):
                    raise _Rollback
                if price > 0:
                    if not await _debit(session, buyer_id, price):
                        raise _Rollback
                    await _credit(session, seller_id, price)
                await _give_item(session, buyer_id, item_id, quantity)
        except _Rollback:
            return False
        return True

    # ----- inventories ---------------------------------------------------

    async def get_quantity(self, user_id: int, item_id: int) -> int:
        stmt = select(InventoryEntry.quantity).where(
            InventoryEntry.user_id == user_id, InventoryEntry.item_id == item_id
        )
        async with self._sessions() as session:
            return (await session.execute(stmt)).scalar_one_or_none() or 0

    async def list_inventory(self, user_id: int) -> list[tuple[InventoryEntry, ShopItem]]:
        stmt = (
            select(InventoryEntry, ShopItem)
            .join(ShopItem, ShopItem.id == InventoryEntry.item_id)
            .where(InventoryEntry.user_id == user_id, InventoryEntry.quantity > 0)
            .order_by(ShopItem.name)
        )
        async with self._sessions() as session:
            return [(entry, item) for entry, item in (await session.execute(stmt)).all()]

    async def give_item(self, user_id: int, item_id: int, quantity: int) -> None:
        """Add items to a user's inventory."""
        async with self._sessions() as session, session.begin():
            await _give_item(session, user_id, item_id, quantity)
