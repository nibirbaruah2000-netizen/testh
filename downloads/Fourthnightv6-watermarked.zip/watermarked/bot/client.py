"""The bot client: wires settings, database, repositories, cogs, and error handling."""
import logging

import discord
from discord import app_commands
from discord.ext import commands

from config import Settings
from database.economy_repository import EconomyRepository
from database.repositories import GuildRepository, ModerationRepository
from database.session import Database

log = logging.getLogger(__name__)

COGS = (
    "cogs.moderation",
    "cogs.moderation_extra",
    "cogs.administration",
    "cogs.economy",
    "cogs.shop",
    "cogs.fun",
    "cogs.utility",
    "cogs.antinuke",
)


class ModBot(commands.AutoShardedBot):
    """Shard-ready bot. Repositories are attached here instead of module globals."""

    def __init__(self, settings: Settings, database: Database) -> None:
        intents = discord.Intents.default()
        # Privileged intent: required for role-hierarchy checks on members.
        intents.members = True

        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=intents,
            owner_id=settings.owner_id,
            help_command=None,
        )
        self.settings = settings
        self.database = database
        self.guild_repo = GuildRepository(database.session_factory)
        self.mod_repo = ModerationRepository(database.session_factory)
        self.economy_repo = EconomyRepository(database.session_factory)
        self.tree.error(self.on_app_command_error)

    async def setup_hook(self) -> None:
        await self.database.create_all()

        for extension in COGS:
            await self.load_extension(extension)
        log.info("Loaded cogs: %s", ", ".join(COGS))

        if not self.settings.sync_commands:
            log.info("Skipping command sync (SYNC_COMMANDS is false).")
            return

        if self.settings.dev_guild_id:
            guild = discord.Object(id=self.settings.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            log.info("Synced commands to dev guild %s", self.settings.dev_guild_id)
        else:
            await self.tree.sync()
            log.info("Synced global commands (may take up to an hour to appear).")

    async def on_ready(self) -> None:
        log.info("Logged in as %s | guilds: %d", self.user, len(self.guilds))

    async def on_guild_join(self, guild: discord.Guild) -> None:
        log.info("Joined guild %s (%s)", guild.name, guild.id)
        await self.guild_repo.get_config(guild.id)

    async def on_app_command_error(
        self, interaction: discord.Interaction, error: app_commands.AppCommandError
    ) -> None:
        """Turn command failures into short, ephemeral messages."""
        original = error.original if isinstance(error, app_commands.CommandInvokeError) else error

        if isinstance(error, app_commands.CheckFailure):
            message = str(error) or "You can't use that command here."
        elif isinstance(original, discord.Forbidden):
            message = "I'm missing the permissions needed for that. Check my role and channel permissions."
        elif isinstance(original, discord.NotFound):
            message = "That target no longer exists."
        elif isinstance(original, discord.HTTPException):
            message = "Discord rejected that request. Please try again."
        else:
            command_name = interaction.command.name if interaction.command else "unknown"
            log.error("Unhandled error in /%s", command_name, exc_info=original)
            message = "Something went wrong. The error has been logged."

        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            log.warning("Could not deliver an error message", exc_info=True)
