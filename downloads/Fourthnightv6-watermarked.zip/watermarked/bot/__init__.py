"""Bot package: the client class and its startup logic."""
