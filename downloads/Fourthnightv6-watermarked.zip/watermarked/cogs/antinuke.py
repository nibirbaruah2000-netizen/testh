"""AntiNuke: detects one user doing too many destructive actions and removes their power."""
import asyncio
import logging
import time
from collections import defaultdict, deque

import discord
from discord import app_commands
from discord.ext import commands

from database.antinuke_repository import AntiNukeRepository
from utils.antinuke import has_dangerous_permission, record_and_check
from utils.embeds import notice_embed

log = logging.getLogger(__name__)

AUDIT_MAX_AGE_SECONDS = 10
AUDIT_ATTEMPTS = 2
AUDIT_RETRY_DELAY = 1.0


class AntiNuke(commands.Cog):
    """Watches destructive actions and punishes the user who does too many."""

    antinuke = app_commands.Group(
        name="antinuke",
        description="Protect this server from mass destructive actions.",
        default_permissions=discord.Permissions(manage_guild=True),
        guild_only=True,
    )

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.repo = AntiNukeRepository(bot.database.session_factory)
        # (guild_id, actor_id, action) -> timestamps of recent actions
        self._windows: dict[tuple[int, int, str], deque[float]] = defaultdict(deque)

    # ----- detection -----------------------------------------------------

    async def _enabled(self, guild: discord.Guild) -> bool:
        return (await self.repo.get_settings(guild.id)).enabled

    async def _find_actor(
        self, guild: discord.Guild, action: discord.AuditLogAction, target_id: int | None = None
    ) -> discord.abc.User | None:
        """Look up who performed a recent audit-log action. Retries once, since logs can lag."""
        for attempt in range(AUDIT_ATTEMPTS):
            try:
                async for entry in guild.audit_logs(limit=10, action=action):
                    age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                    if age > AUDIT_MAX_AGE_SECONDS:
                        break
                    if target_id is not None and getattr(entry.target, "id", None) != target_id:
                        continue
                    return entry.user
            except discord.HTTPException:
                log.warning("Could not read audit log in guild %s", guild.id, exc_info=True)
                return None
            if attempt < AUDIT_ATTEMPTS - 1:
                await asyncio.sleep(AUDIT_RETRY_DELAY)
        return None

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        if not await self._enabled(channel.guild):
            return
        actor = await self._find_actor(channel.guild, discord.AuditLogAction.channel_delete, channel.id)
        await self._record(channel.guild, actor, "channel delete")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role) -> None:
        if not await self._enabled(role.guild):
            return
        actor = await self._find_actor(role.guild, discord.AuditLogAction.role_delete, role.id)
        await self._record(role.guild, actor, "role delete")

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User) -> None:
        if not await self._enabled(guild):
            return
        actor = await self._find_actor(guild, discord.AuditLogAction.ban, user.id)
        await self._record(guild, actor, "ban")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        if not await self._enabled(member.guild):
            return
        # Only count it if the audit log shows a kick. Normal leaves are not counted.
        actor = await self._find_actor(member.guild, discord.AuditLogAction.kick, member.id)
        await self._record(member.guild, actor, "kick")

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: discord.abc.GuildChannel) -> None:
        if not await self._enabled(channel.guild):
            return
        actor = await self._find_actor(channel.guild, discord.AuditLogAction.webhook_create)
        await self._record(channel.guild, actor, "webhook create")

    async def _record(self, guild: discord.Guild, actor: discord.abc.User | None, action: str) -> None:
        if actor is None or actor.id == self.bot.user.id:
            return
        settings = await self.repo.get_settings(guild.id)
        if not settings.enabled or actor.id == guild.owner_id:
            return
        if actor.id in await self.repo.allowlist(guild.id):
            return

        window = self._windows[(guild.id, actor.id, action)]
        if record_and_check(window, time.monotonic(), settings.window_seconds, settings.threshold):
            await self._punish(guild, actor, action, settings)

    # ----- response ------------------------------------------------------

    async def _punish(self, guild: discord.Guild, actor: discord.abc.User, action: str, settings) -> None:
        reason = f"AntiNuke: {settings.threshold}+ {action} in {settings.window_seconds}s"
        try:
            if settings.punishment == "ban":
                await guild.ban(actor, reason=reason)
                result = "Banned."
            else:
                result = await self._strip_power(guild, actor, reason)
        except discord.HTTPException:
            log.exception("AntiNuke punishment failed in guild %s", guild.id)
            result = "Punishment failed. Check my role position and permissions."

        embed = notice_embed(
            "AntiNuke triggered",
            f"{actor.mention} hit the limit for **{action}** "
            f"({settings.threshold} in {settings.window_seconds}s).\n\n**Response:** {result}",
        )
        config = await self.bot.guild_repo.get_config(guild.id)
        if config.log_channel_id:
            channel = guild.get_channel(config.log_channel_id)
            if isinstance(channel, discord.TextChannel):
                try:
                    await channel.send(embed=embed)
                except discord.HTTPException:
                    log.warning("Could not post AntiNuke alert in guild %s", guild.id)

    async def _strip_power(self, guild: discord.Guild, actor: discord.abc.User, reason: str) -> str:
        member = guild.get_member(actor.id)
        if member is None:
            return "User is no longer in the server. Nothing to remove."

        me = guild.me
        dangerous = [r for r in member.roles if not r.is_default() and has_dangerous_permission(r)]
        removable = [r for r in dangerous if r.position < me.top_role.position]
        out_of_reach = len(dangerous) - len(removable)

        if not dangerous:
            return "No dangerous roles to remove."
        if removable:
            await member.remove_roles(*removable, reason=reason)
        text = f"Removed {len(removable)} dangerous role(s)."
        if out_of_reach:
            text += f" {out_of_reach} role(s) are above my role and need a manual fix."
        return text

    # ----- commands ------------------------------------------------------

    @antinuke.command(name="status", description="Show AntiNuke settings.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def status(self, interaction: discord.Interaction) -> None:
        settings = await self.repo.get_settings(interaction.guild.id)
        allowed = await self.repo.allowlist(interaction.guild.id)
        embed = discord.Embed(title="AntiNuke", colour=discord.Colour.blurple())
        embed.add_field(name="Enabled", value="Yes" if settings.enabled else "No")
        embed.add_field(name="Limit", value=f"{settings.threshold} actions in {settings.window_seconds}s")
        embed.add_field(name="Punishment", value=settings.punishment)
        embed.add_field(name="Allowlisted users", value=str(len(allowed)))
        embed.set_footer(text="Watches: channel/role deletes, bans, kicks, webhook creation.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @antinuke.command(name="toggle", description="Turn AntiNuke on or off.")
    @app_commands.describe(enabled="True to turn it on, False to turn it off.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def toggle(self, interaction: discord.Interaction, enabled: bool) -> None:
        await self.repo.update_settings(interaction.guild.id, enabled=enabled)
        await interaction.response.send_message(
            f"AntiNuke is now **{'on' if enabled else 'off'}**.", ephemeral=True
        )

    @antinuke.command(name="threshold", description="Set how many actions trigger AntiNuke, and within how long.")
    @app_commands.describe(actions="Actions by one user (2 to 50).", seconds="Time window in seconds (1 to 300).")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def threshold(
        self,
        interaction: discord.Interaction,
        actions: app_commands.Range[int, 2, 50],
        seconds: app_commands.Range[int, 1, 300],
    ) -> None:
        await self.repo.update_settings(interaction.guild.id, threshold=actions, window_seconds=seconds)
        await interaction.response.send_message(
            f"AntiNuke will trigger after {actions} actions in {seconds}s.", ephemeral=True
        )

    @antinuke.command(name="punishment", description="Choose what happens to a user who triggers AntiNuke.")
    @app_commands.describe(choice="strip removes dangerous roles. ban bans the user.")
    @app_commands.choices(
        choice=[
            app_commands.Choice(name="Strip dangerous roles", value="strip"),
            app_commands.Choice(name="Ban", value="ban"),
        ]
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def punishment(self, interaction: discord.Interaction, choice: app_commands.Choice[str]) -> None:
        await self.repo.update_settings(interaction.guild.id, punishment=choice.value)
        await interaction.response.send_message(f"Punishment set to **{choice.name}**.", ephemeral=True)

    @antinuke.command(name="allow", description="Exempt a user from AntiNuke.")
    @app_commands.describe(user="The user or bot to exempt.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def allow(self, interaction: discord.Interaction, user: discord.User) -> None:
        if await self.repo.allow(interaction.guild.id, user.id):
            text = f"{user.mention} is now exempt from AntiNuke."
        else:
            text = f"{user.mention} is already exempt."
        await interaction.response.send_message(text, ephemeral=True)

    @antinuke.command(name="disallow", description="Remove a user's AntiNuke exemption.")
    @app_commands.describe(user="The user to remove from the allowlist.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def disallow(self, interaction: discord.Interaction, user: discord.User) -> None:
        if await self.repo.disallow(interaction.guild.id, user.id):
            text = f"{user.mention} is no longer exempt."
        else:
            text = f"{user.mention} wasn't on the allowlist."
        await interaction.response.send_message(text, ephemeral=True)

    @antinuke.command(name="allowlist", description="List users exempt from AntiNuke.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def allowlist(self, interaction: discord.Interaction) -> None:
        user_ids = await self.repo.allowlist(interaction.guild.id)
        if not user_ids:
            text = "No users are exempt."
        else:
            text = "\n".join(f"<@{uid}>" for uid in user_ids)
        await interaction.response.send_message(text, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(AntiNuke(bot))
