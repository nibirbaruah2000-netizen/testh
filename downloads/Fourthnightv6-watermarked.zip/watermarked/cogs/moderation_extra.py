"""Extra moderation: nicknames, removing warnings, and softbans."""
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.checks import moderator_check
from utils.embeds import case_embed, notice_embed


class ModerationExtra(commands.Cog):
    """Commands that reuse the Moderation cog's permission and case logic."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    def _moderation(self):
        cog = self.bot.get_cog("Moderation")
        if cog is None:
            raise RuntimeError("Moderation cog is not loaded")
        return cog

    @app_commands.command(name="nick", description="Change or reset a member's nickname.")
    @app_commands.describe(member="The member to rename.", nickname="New nickname. Leave empty to reset.")
    @moderator_check("manage_nicknames")
    async def nick(
        self, interaction: discord.Interaction, member: discord.Member, nickname: Optional[str] = None
    ) -> None:
        if nickname is not None and len(nickname) > 32:
            await interaction.response.send_message("Nicknames must be 32 characters or fewer.", ephemeral=True)
            return
        if error := self._moderation()._guard_target(interaction, member):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await member.edit(nick=nickname, reason=f"Nickname changed by {interaction.user}")
        text = f"Nickname for {member.mention} set to **{nickname}**." if nickname else f"Reset {member.mention}'s nickname."
        await interaction.response.send_message(text)

    @app_commands.command(name="removewarn", description="Remove one specific warning by its ID.")
    @app_commands.describe(warning_id="The warning ID shown by /warnings.")
    @moderator_check("moderate_members")
    async def removewarn(self, interaction: discord.Interaction, warning_id: int) -> None:
        removed = await self.bot.mod_repo.remove_warning(interaction.guild.id, warning_id)
        if not removed:
            await interaction.response.send_message("No active warning with that ID in this server.", ephemeral=True)
            return
        await interaction.response.send_message(
            embed=notice_embed("Warning removed", f"Warning #{warning_id} has been removed.")
        )

    @app_commands.command(name="softban", description="Ban and immediately unban a member to clear their recent messages.")
    @app_commands.describe(member="The member to softban.", reason="Why.")
    @moderator_check("ban_members")
    async def softban(
        self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"
    ) -> None:
        moderation = self._moderation()
        if error := moderation._guard_target(interaction, member):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await interaction.response.defer()
        guild = interaction.guild
        await guild.ban(member, reason=f"Softban: {reason} (by {interaction.user})")
        await guild.unban(member, reason="Softban complete")
        case = await moderation._record_case(
            guild, interaction.user, member.id, member.mention, "softban", reason
        )
        await interaction.followup.send(embed=case_embed(case, member.mention, interaction.user.mention))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ModerationExtra(bot))
