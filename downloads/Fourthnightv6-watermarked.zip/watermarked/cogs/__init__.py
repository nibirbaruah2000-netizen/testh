"""Command cogs. Each file is loaded as an extension."""
