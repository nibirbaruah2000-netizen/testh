"""Moderation commands: kick, ban, timeouts, warnings, purge, slowmode, channel lock, cases."""
import logging
from datetime import timedelta
from typing import TYPE_CHECKING, Optional, cast

import discord
from discord import app_commands
from discord.ext import commands

from database.models import GuildConfig, ModCase
from utils.checks import moderator_check
from utils.embeds import case_embed, cases_embed, notice_embed, warnings_embed
from utils.permissions import check_hierarchy, check_identity

if TYPE_CHECKING:
    from bot.client import ModBot

log = logging.getLogger(__name__)
REASON_DEFAULT = "No reason provided"


def _audit(interaction: discord.Interaction, reason: str) -> str:
    return f"{reason} (by {interaction.user})"


class Moderation(commands.Cog):
    """Slash commands for moderating a server."""

    def __init__(self, bot: "ModBot") -> None:
        self.bot = bot

    # ----- helpers -------------------------------------------------------

    def _guard_target(
        self, interaction: discord.Interaction, target: discord.abc.Snowflake
    ) -> Optional[str]:
        """Return an error message if the invoker may not act on the target, else None."""
        guild = interaction.guild
        if guild is None:
            return "This command can only be used in a server."
        actor = cast(discord.Member, interaction.user)
        member = target if isinstance(target, discord.Member) else guild.get_member(target.id)
        if member is None:
            # Target is not in the server (e.g. a ban by ID): only identity rules apply.
            return check_identity(actor.id, target.id, guild.me.id, guild.owner_id)
        return check_hierarchy(actor, member, guild.me, guild.owner_id)

    async def _record_case(
        self,
        guild: discord.Guild,
        moderator: discord.abc.User,
        target_id: int,
        target_label: str,
        action: str,
        reason: str,
        duration_seconds: Optional[int] = None,
    ) -> ModCase:
        case = await self.bot.mod_repo.add_case(
            guild.id, target_id, moderator.id, action, reason, duration_seconds
        )
        config = await self.bot.guild_repo.get_config(guild.id)
        if config.log_channel_id:
            channel = guild.get_channel(config.log_channel_id)
            if isinstance(channel, discord.TextChannel):
                try:
                    await channel.send(embed=case_embed(case, target_label, moderator.mention))
                except discord.HTTPException:
                    log.warning("Could not post case %s to log channel in guild %s", case.case_number, guild.id)
        return case

    async def _apply_warn_thresholds(
        self,
        guild: discord.Guild,
        moderator: discord.abc.User,
        member: discord.Member,
        count: int,
        config: GuildConfig,
    ) -> Optional[str]:
        """Apply the automatic punishment for the current warning count, if a threshold is reached."""
        reason = f"Automatic: {count} active warnings"
        try:
            if count >= config.warn_ban_threshold:
                await member.ban(reason=reason)
                action, duration = "ban", None
            elif count >= config.warn_kick_threshold:
                await member.kick(reason=reason)
                action, duration = "kick", None
            elif count >= config.warn_timeout_threshold:
                duration = config.auto_timeout_minutes * 60
                until = discord.utils.utcnow() + timedelta(seconds=duration)
                await member.timeout(until, reason=reason)
                action = "timeout"
            else:
                return None
        except discord.HTTPException:
            log.warning("Automatic action failed in guild %s", guild.id, exc_info=True)
            return "automatic action failed (check my permissions and role position)"

        await self._record_case(guild, moderator, member.id, member.mention, action, reason, duration)
        return action

    # ----- member actions ------------------------------------------------

    @app_commands.command(name="kick", description="Kick a member from the server.")
    @app_commands.describe(member="The member to kick.", reason="Why they are being kicked.")
    @moderator_check("kick_members")
    async def kick(
        self, interaction: discord.Interaction, member: discord.Member, reason: str = REASON_DEFAULT
    ) -> None:
        if error := self._guard_target(interaction, member):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await interaction.response.defer()
        await member.kick(reason=_audit(interaction, reason))
        case = await self._record_case(
            interaction.guild, interaction.user, member.id, member.mention, "kick", reason
        )
        await interaction.followup.send(embed=case_embed(case, member.mention, interaction.user.mention))

    @app_commands.command(name="ban", description="Ban a user from the server.")
    @app_commands.describe(user="The user to ban.", reason="Why they are being banned.")
    @moderator_check("ban_members")
    async def ban(
        self, interaction: discord.Interaction, user: discord.User, reason: str = REASON_DEFAULT
    ) -> None:
        if error := self._guard_target(interaction, user):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await interaction.response.defer()
        await interaction.guild.ban(user, reason=_audit(interaction, reason))
        case = await self._record_case(
            interaction.guild, interaction.user, user.id, user.mention, "ban", reason
        )
        await interaction.followup.send(embed=case_embed(case, user.mention, interaction.user.mention))

    @app_commands.command(name="unban", description="Unban a user by their ID.")
    @app_commands.describe(user_id="The Discord ID of the banned user.", reason="Why the ban is lifted.")
    @moderator_check("ban_members")
    async def unban(
        self, interaction: discord.Interaction, user_id: str, reason: str = REASON_DEFAULT
    ) -> None:
        try:
            target_id = int(user_id)
        except ValueError:
            await interaction.response.send_message("That isn't a valid user ID.", ephemeral=True)
            return
        await interaction.response.defer()
        try:
            await interaction.guild.unban(discord.Object(id=target_id), reason=_audit(interaction, reason))
        except discord.NotFound:
            await interaction.followup.send("That user isn't banned here.", ephemeral=True)
            return
        case = await self._record_case(
            interaction.guild, interaction.user, target_id, f"<@{target_id}>", "unban", reason
        )
        await interaction.followup.send(embed=case_embed(case, f"<@{target_id}>", interaction.user.mention))

    @app_commands.command(name="timeout", description="Temporarily stop a member from chatting.")
    @app_commands.describe(
        member="The member to time out.",
        minutes="Length of the timeout (1 to 40320, which is 28 days).",
        reason="Why they are being timed out.",
    )
    @moderator_check("moderate_members")
    async def timeout(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutes: app_commands.Range[int, 1, 40320],
        reason: str = REASON_DEFAULT,
    ) -> None:
        if error := self._guard_target(interaction, member):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await interaction.response.defer()
        duration_seconds = minutes * 60
        until = discord.utils.utcnow() + timedelta(seconds=duration_seconds)
        await member.timeout(until, reason=_audit(interaction, reason))
        case = await self._record_case(
            interaction.guild, interaction.user, member.id, member.mention, "timeout", reason, duration_seconds
        )
        await interaction.followup.send(embed=case_embed(case, member.mention, interaction.user.mention))

    @app_commands.command(name="untimeout", description="Remove a member's timeout.")
    @app_commands.describe(member="The member to release.")
    @moderator_check("moderate_members")
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member) -> None:
        if error := self._guard_target(interaction, member):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await member.timeout(None, reason=_audit(interaction, "Timeout removed"))
        case = await self._record_case(
            interaction.guild, interaction.user, member.id, member.mention, "untimeout", "Timeout removed"
        )
        await interaction.response.send_message(embed=case_embed(case, member.mention, interaction.user.mention))

    # ----- warnings ------------------------------------------------------

    @app_commands.command(name="warn", description="Warn a member. Thresholds may trigger automatic action.")
    @app_commands.describe(member="The member to warn.", reason="Why they are being warned.")
    @moderator_check("moderate_members")
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str) -> None:
        if error := self._guard_target(interaction, member):
            await interaction.response.send_message(error, ephemeral=True)
            return
        await interaction.response.defer()
        guild = interaction.guild

        await self.bot.mod_repo.add_warning(guild.id, member.id, interaction.user.id, reason)
        count = await self.bot.mod_repo.count_active_warnings(guild.id, member.id)
        config = await self.bot.guild_repo.get_config(guild.id)

        case = await self._record_case(guild, interaction.user, member.id, member.mention, "warn", reason)
        outcome = await self._apply_warn_thresholds(guild, interaction.user, member, count, config)

        embed = case_embed(case, member.mention, interaction.user.mention)
        embed.add_field(name="Active warnings", value=str(count))
        if outcome:
            embed.add_field(name="Automatic action", value=outcome, inline=False)
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="warnings", description="List a member's active warnings.")
    @app_commands.describe(member="The member to look up.")
    @moderator_check("moderate_members")
    async def warnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        guild = interaction.guild
        records = await self.bot.mod_repo.list_active_warnings(guild.id, member.id)
        total = await self.bot.mod_repo.count_active_warnings(guild.id, member.id)
        await interaction.response.send_message(
            embed=warnings_embed(member.mention, records, total), ephemeral=True
        )

    @app_commands.command(name="clearwarnings", description="Clear all active warnings for a member.")
    @app_commands.describe(member="The member whose warnings will be cleared.")
    @moderator_check("moderate_members")
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        cleared = await self.bot.mod_repo.clear_warnings(interaction.guild.id, member.id)
        await interaction.response.send_message(
            embed=notice_embed("Warnings cleared", f"Cleared {cleared} warning(s) for {member.mention}.")
        )

    # ----- channel tools -------------------------------------------------

    @app_commands.command(name="purge", description="Bulk delete recent messages in this channel.")
    @app_commands.describe(amount="How many messages to delete (1 to 100).")
    @moderator_check("manage_messages")
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]) -> None:
        channel = interaction.channel
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            await interaction.response.send_message(
                "This command only works in text channels and threads.", ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True)
        deleted = await channel.purge(limit=amount)
        await interaction.followup.send(f"Deleted {len(deleted)} message(s).", ephemeral=True)

    @app_commands.command(name="slowmode", description="Set the slowmode delay for this channel.")
    @app_commands.describe(seconds="Delay between messages in seconds. 0 turns it off (max 21600).")
    @moderator_check("manage_channels")
    async def slowmode(self, interaction: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]) -> None:
        channel = interaction.channel
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            await interaction.response.send_message(
                "This command only works in text channels and threads.", ephemeral=True
            )
            return
        await channel.edit(slowmode_delay=seconds, reason=_audit(interaction, "Slowmode changed"))
        text = f"Slowmode set to {seconds} second(s)." if seconds else "Slowmode turned off."
        await interaction.response.send_message(text)

    async def _set_channel_locked(self, interaction: discord.Interaction, locked: bool) -> None:
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message("This command only works in text channels.", ephemeral=True)
            return
        await interaction.response.defer()
        guild = interaction.guild
        overwrite = channel.overwrites_for(guild.default_role)
        overwrite.send_messages = False if locked else None
        action = "lock" if locked else "unlock"
        await channel.set_permissions(
            guild.default_role, overwrite=overwrite, reason=_audit(interaction, f"Channel {action}ed")
        )
        case = await self._record_case(
            guild, interaction.user, channel.id, channel.mention, action, f"Channel {action}ed"
        )
        await interaction.followup.send(embed=case_embed(case, channel.mention, interaction.user.mention))

    @app_commands.command(name="lock", description="Stop everyone from sending messages in this channel.")
    @moderator_check("manage_channels")
    async def lock(self, interaction: discord.Interaction) -> None:
        await self._set_channel_locked(interaction, locked=True)

    @app_commands.command(name="unlock", description="Allow messages again in this channel.")
    @moderator_check("manage_channels")
    async def unlock(self, interaction: discord.Interaction) -> None:
        await self._set_channel_locked(interaction, locked=False)

    # ----- case lookup ---------------------------------------------------

    @app_commands.command(name="case", description="Show a moderation case by number.")
    @app_commands.describe(number="The case number shown in the log.")
    @moderator_check("moderate_members")
    async def case(self, interaction: discord.Interaction, number: int) -> None:
        record = await self.bot.mod_repo.get_case(interaction.guild.id, number)
        if record is None:
            await interaction.response.send_message(f"No case #{number} exists in this server.", ephemeral=True)
            return
        await interaction.response.send_message(
            embed=case_embed(record, f"<@{record.target_id}>", f"<@{record.moderator_id}>"),
            ephemeral=True,
        )

    @app_commands.command(name="cases", description="List recent moderation cases for a member.")
    @app_commands.describe(member="The member to look up.")
    @moderator_check("moderate_members")
    async def cases(self, interaction: discord.Interaction, member: discord.Member) -> None:
        records = await self.bot.mod_repo.list_cases(interaction.guild.id, member.id)
        await interaction.response.send_message(embed=cases_embed(member.mention, records), ephemeral=True)


async def setup(bot: "ModBot") -> None:
    await bot.add_cog(Moderation(bot))
