"""General utility and info commands."""
import asyncio
import logging
from datetime import timedelta
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from config import BOT_NAME
from utils.branding import add_brand
from utils.checks import moderator_check
from utils.embeds import notice_embed

log = logging.getLogger(__name__)

INVITE_PERMISSIONS = discord.Permissions(
    kick_members=True,
    ban_members=True,
    moderate_members=True,
    manage_messages=True,
    manage_channels=True,
    manage_nicknames=True,
    manage_roles=True,
    view_audit_log=True,
    view_channel=True,
    send_messages=True,
    embed_links=True,
    read_message_history=True,
)
POLL_EMOJIS = ["1️⃣", "2️⃣", "3️⃣"]


def _uptime_text(delta: timedelta) -> str:
    total = int(delta.total_seconds())
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    return f"{days}d {hours}h {minutes}m {seconds}s"


class Utility(commands.Cog):
    """Info, polls, reminders, and help."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.started_at = discord.utils.utcnow()
        self._tasks: set[asyncio.Task] = set()

    @app_commands.command(name="ping", description="Check the bot's response time.")
    async def ping(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(f"Pong! {round(self.bot.latency * 1000)} ms")

    @app_commands.command(name="userinfo", description="Show information about a member.")
    @app_commands.describe(user="The member to look up. Defaults to you.")
    async def userinfo(self, interaction: discord.Interaction, user: Optional[discord.Member] = None) -> None:
        target = user or interaction.user
        embed = discord.Embed(title=target.display_name, colour=discord.Colour.blurple())
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="User ID", value=str(target.id))
        embed.add_field(name="Account created", value=discord.utils.format_dt(target.created_at, "D"))
        if isinstance(target, discord.Member) and target.joined_at:
            embed.add_field(name="Joined server", value=discord.utils.format_dt(target.joined_at, "D"))
            embed.add_field(name="Roles", value=str(len(target.roles) - 1))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="serverinfo", description="Show information about this server.")
    async def serverinfo(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        embed = discord.Embed(title=guild.name, colour=discord.Colour.blurple())
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner", value=f"<@{guild.owner_id}>")
        embed.add_field(name="Members", value=str(guild.member_count))
        embed.add_field(name="Channels", value=str(len(guild.channels)))
        embed.add_field(name="Roles", value=str(len(guild.roles)))
        embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, "D"))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="avatar", description="Show a user's avatar.")
    @app_commands.describe(user="The user. Defaults to you.")
    async def avatar(self, interaction: discord.Interaction, user: Optional[discord.User] = None) -> None:
        target = user or interaction.user
        embed = discord.Embed(title=f"{target.display_name}'s avatar", colour=discord.Colour.blurple())
        embed.set_image(url=target.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="poll", description="Create a poll with up to three options.")
    @app_commands.describe(
        question="The poll question.",
        option_a="First option.",
        option_b="Second option.",
        option_c="Optional third option.",
    )
    async def poll(
        self,
        interaction: discord.Interaction,
        question: app_commands.Range[str, 1, 200],
        option_a: app_commands.Range[str, 1, 80],
        option_b: app_commands.Range[str, 1, 80],
        option_c: Optional[str] = None,
    ) -> None:
        if option_c is not None and len(option_c) > 80:
            await interaction.response.send_message("Option C must be 80 characters or fewer.", ephemeral=True)
            return
        options = [o for o in (option_a, option_b, option_c) if o]
        lines = "\n".join(f"{POLL_EMOJIS[i]} {text}" for i, text in enumerate(options))
        embed = discord.Embed(title=f"📊 {question}", description=lines, colour=discord.Colour.blurple())
        await interaction.response.send_message(embed=embed)
        message = await interaction.original_response()
        for i in range(len(options)):
            await message.add_reaction(POLL_EMOJIS[i])

    @app_commands.command(name="remindme", description="Get a reminder in this channel after some minutes.")
    @app_commands.describe(minutes="Minutes from now (1 to 10080).", message="What to remind you about.")
    async def remindme(
        self,
        interaction: discord.Interaction,
        minutes: app_commands.Range[int, 1, 10080],
        message: app_commands.Range[str, 1, 500],
    ) -> None:
        channel = interaction.channel
        if channel is None:
            await interaction.response.send_message("I can't set a reminder here.", ephemeral=True)
            return
        task = asyncio.create_task(self._remind(channel, interaction.user.mention, minutes, message))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        await interaction.response.send_message(f"Okay, I'll remind you in {minutes} minute(s).", ephemeral=True)

    async def _remind(self, channel, mention: str, minutes: int, message: str) -> None:
        await asyncio.sleep(minutes * 60)
        try:
            await channel.send(f"{mention} Reminder: {message}")
        except discord.HTTPException:
            log.warning("Could not deliver reminder", exc_info=True)

    @app_commands.command(name="say", description="Make the bot say something in this channel.")
    @app_commands.describe(text="What the bot should say.")
    @moderator_check("manage_messages")
    async def say(self, interaction: discord.Interaction, text: app_commands.Range[str, 1, 1500]) -> None:
        channel = interaction.channel
        if channel is None:
            await interaction.response.send_message("I can't send messages here.", ephemeral=True)
            return
        await channel.send(text, allowed_mentions=discord.AllowedMentions.none())
        await interaction.response.send_message("Sent.", ephemeral=True)

    @app_commands.command(name="uptime", description="Show how long the bot has been running.")
    async def uptime(self, interaction: discord.Interaction) -> None:
        delta = discord.utils.utcnow() - self.started_at
        await interaction.response.send_message(f"⏱️ Online for {_uptime_text(delta)}.")

    @app_commands.command(name="help", description="List all commands.")
    async def help(self, interaction: discord.Interaction) -> None:
        lines = []
        for cmd in self.bot.tree.get_commands():
            if isinstance(cmd, app_commands.Group):
                for sub in cmd.commands:
                    lines.append(f"`/{cmd.name} {sub.name}` — {sub.description}")
            else:
                lines.append(f"`/{cmd.name}` — {cmd.description}")
        embed = discord.Embed(title=f"{BOT_NAME} commands", description="\n".join(sorted(lines))[:4000], colour=discord.Colour.blurple())
        await interaction.response.send_message(embed=add_brand(embed), ephemeral=True)

    @app_commands.command(name="invite", description="Get the link to add this bot to another server.")
    async def invite(self, interaction: discord.Interaction) -> None:
        url = discord.utils.oauth_url(
            self.bot.application_id,
            permissions=INVITE_PERMISSIONS,
            scopes=("bot", "applications.commands"),
        )
        await interaction.response.send_message(f"Add me to your server: {url}", ephemeral=True)

    @app_commands.command(name="botstats", description="Show bot statistics.")
    async def botstats(self, interaction: discord.Interaction) -> None:
        guilds = self.bot.guilds
        members = sum(g.member_count or 0 for g in guilds)
        embed = discord.Embed(title=f"{BOT_NAME} statistics", colour=discord.Colour.blurple())
        embed.add_field(name="Servers", value=str(len(guilds)))
        embed.add_field(name="Members (approx.)", value=str(members))
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)} ms")
        await interaction.response.send_message(embed=add_brand(embed))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Utility(bot))
