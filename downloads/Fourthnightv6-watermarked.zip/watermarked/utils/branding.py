"""Adds the attribution line to embeds. Does nothing when BRAND_LINE is empty."""
import discord

from config import BRAND_LINE


def add_brand(embed: discord.Embed) -> discord.Embed:
    if BRAND_LINE:
        embed.add_field(name="\u200b", value=BRAND_LINE, inline=False)
    return embed
