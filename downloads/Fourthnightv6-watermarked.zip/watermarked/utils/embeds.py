"""Shared embed builders so every command looks consistent."""
from typing import Sequence

import discord

from database.models import ModCase, WarningRecord

ACCENT = discord.Colour.blurple()


def _clip(text: str, limit: int = 1000) -> str:
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _duration_text(seconds: int | None) -> str | None:
    if not seconds:
        return None
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes} min"
    hours, remainder = divmod(minutes, 60)
    return f"{hours}h {remainder}m" if remainder else f"{hours}h"


def case_embed(case: ModCase, target_label: str, moderator_label: str) -> discord.Embed:
    """Embed for one moderation case."""
    embed = discord.Embed(
        title=f"Case #{case.case_number} · {case.action.title()}",
        colour=ACCENT,
        timestamp=case.created_at,
    )
    embed.add_field(name="Target", value=target_label)
    embed.add_field(name="Moderator", value=moderator_label)
    embed.add_field(name="Reason", value=_clip(case.reason or "No reason provided"), inline=False)
    duration = _duration_text(case.duration_seconds)
    if duration:
        embed.add_field(name="Duration", value=duration)
    return embed


def warnings_embed(target_label: str, records: Sequence[WarningRecord], total: int) -> discord.Embed:
    """Embed listing a member's active warnings."""
    embed = discord.Embed(title=f"Warnings for {target_label}", colour=ACCENT)
    embed.description = f"**{total}** active warning(s)"
    if not records:
        embed.add_field(name="No active warnings", value="This member is in good standing.", inline=False)
        return embed
    for record in records:
        when = discord.utils.format_dt(record.created_at, "d")
        embed.add_field(
            name=f"Warning #{record.id} · {when}",
            value=_clip(f"{record.reason}\nBy <@{record.moderator_id}>", 1024),
            inline=False,
        )
    return embed


def cases_embed(target_label: str, cases: Sequence[ModCase]) -> discord.Embed:
    """Embed listing a member's recent cases."""
    embed = discord.Embed(title=f"Cases for {target_label}", colour=ACCENT)
    if not cases:
        embed.description = "No moderation cases on record."
        return embed
    for case in cases:
        embed.add_field(
            name=f"Case #{case.case_number} · {case.action.title()}",
            value=_clip(case.reason or "No reason provided", 1024),
            inline=False,
        )
    return embed


def notice_embed(title: str, description: str) -> discord.Embed:
    """Simple titled embed for confirmations."""
    return discord.Embed(title=title, description=description, colour=ACCENT)
