"""Command check decorators that combine Discord permissions with the configured mod role."""
import discord
from discord import app_commands

from utils.permissions import has_staff_role


def moderator_check(permission: str):
    """Allow the command if the member has `permission` or the server's moderator role."""

    async def predicate(interaction: discord.Interaction) -> bool:
        member = interaction.user
        if interaction.guild is None or not isinstance(member, discord.Member):
            raise app_commands.CheckFailure("This command can only be used in a server.")

        config = await interaction.client.guild_repo.get_config(interaction.guild.id)  # type: ignore[attr-defined]
        if has_staff_role(member, config.mod_role_id):
            return True
        if getattr(member.guild_permissions, permission, False):
            return True

        label = permission.replace("_", " ").title()
        raise app_commands.CheckFailure(
            f"You need the **{label}** permission or the configured moderator role."
        )

    return app_commands.check(predicate)
