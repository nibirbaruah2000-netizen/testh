"""Pure AntiNuke rules. No Discord or database access, so they are easy to test."""
from collections import deque

DANGEROUS_PERMISSIONS = (
    "administrator",
    "manage_guild",
    "manage_roles",
    "manage_channels",
    "ban_members",
    "kick_members",
    "manage_webhooks",
)


def has_dangerous_permission(role) -> bool:
    """True if the role grants any permission that can damage the server."""
    return any(getattr(role.permissions, name) for name in DANGEROUS_PERMISSIONS)


def record_and_check(window: deque, now: float, window_seconds: float, threshold: int) -> bool:
    """Record one action. Returns True when the user has hit the threshold inside the window.

    The window is cleared on trigger so one burst causes one punishment.
    """
    window.append(now)
    while window and now - window[0] > window_seconds:
        window.popleft()
    if len(window) >= threshold:
        window.clear()
        return True
    return False
