"""Environment-driven configuration. Nothing sensitive is hard-coded."""
from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()

BOT_NAME = "Fourthnight"
DEFAULT_DATABASE_URL = "sqlite+aiosqlite:///data/bot.db"


@dataclass(frozen=True)
class Settings:
    """Typed view of the environment variables the bot needs."""

    discord_token: str
    database_url: str
    owner_id: int | None
    dev_guild_id: int | None
    log_level: str
    sync_commands: bool


def _optional_int(name: str) -> int | None:
    raw = os.getenv(name, "").strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc


def load_settings() -> Settings:
    """Read and validate settings from the environment."""
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token:
        raise RuntimeError("DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.")

    return Settings(
        discord_token=token,
        database_url=os.getenv("DATABASE_URL", "").strip() or DEFAULT_DATABASE_URL,
        owner_id=_optional_int("OWNER_ID"),
        dev_guild_id=_optional_int("DEV_GUILD_ID"),
        log_level=os.getenv("LOG_LEVEL", "INFO").strip() or "INFO",
        sync_commands=os.getenv("SYNC_COMMANDS", "false").strip().lower()
        in {"1", "true", "yes", "on"},
    )

# Attribution line shown in /help and /botstats. Set to "" to disable.
BRAND_LINE = "<a:OwnedByNimble:1561392815844360364> Fourthnight Open-source, Devloped by NimbleFlea8613"
