package com.example.nodeath;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class NoDeathPlugin extends JavaPlugin implements Listener {

    private static final String DEATH_TITLE = "You Should Have Died......";
    private static final long TWO_SECONDS = 40L; // ticks

    /** Players currently waiting for the 2-second item drop. */
    private final Set<UUID> pending = new HashSet<>();

    /** Marks items that were picked up in the Nether or End. */
    private NamespacedKey netherEndKey;

    @Override
    public void onEnable() {
        netherEndKey = new NamespacedKey(this, "found_nether_end");
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("NoDeath enabled. Nobody is dying today.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLethalDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        if (player.getHealth() - event.getFinalDamage() > 0) return;

        event.setCancelled(true);

        if (!pending.add(player.getUniqueId())) return;

        player.setHealth(1.0);
        player.setFireTicks(0);
        player.setFallDistance(0f);

        if (event.getCause() == EntityDamageEvent.DamageCause.VOID) {
            World world = player.getWorld();
            player.teleport(world.getSpawnLocation());
        }

        player.sendTitle(DEATH_TITLE, "", 0, (int) TWO_SECONDS, 10);

        Bukkit.getScheduler().runTaskLater(this, () -> {
            pending.remove(player.getUniqueId());
            if (player.isOnline()) {
                dropAndWipe(player);
            }
        }, TWO_SECONDS);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        World.Environment env = player.getWorld().getEnvironment();
        if (env != World.Environment.NETHER && env != World.Environment.THE_END) return;

        Item itemEntity = event.getItem();
        ItemStack stack = itemEntity.getItemStack();
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return;

        meta.getPersistentDataContainer().set(netherEndKey, PersistentDataType.BYTE, (byte) 1);
        stack.setItemMeta(meta);
        itemEntity.setItemStack(stack);
    }

    private void dropAndWipe(Player player) {
        PlayerInventory inv = player.getInventory();
        Location loc = player.getLocation();
        World world = player.getWorld();

        // Slots: 0-35 main inventory, 36-39 armour, 40 offhand
        ItemStack[] contents = inv.getContents();

        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack item = contents[slot];
            if (item == null || item.getType().isAir()) continue;

            boolean isArmour = slot >= 36 && slot <= 39;
            boolean isNetherEnd = isNetherEndItem(item);

            if (isArmour || isNetherEnd) {
                inv.setItem(slot, null);
            } else {
                world.dropItemNaturally(loc, item);
                inv.setItem(slot, null);
            }
        }

        player.updateInventory();
    }

    private boolean isNetherEndItem(ItemStack item) {
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta != null
                && meta.getPersistentDataContainer().has(netherEndKey, PersistentDataType.BYTE);
    }
}
